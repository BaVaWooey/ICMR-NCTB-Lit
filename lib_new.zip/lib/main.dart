// ignore_for_file: camel_case_types

import 'screen/screens.dart';
import 'phonemic_fluency/instructions.dart';
import 'categoric_fluency/categoric_fluency_main.dart';
import 'moca/main.dart';
import 'verbal_recognition/verbal_instructions.dart';
import 'delayed_recall_recognition/imports.dart';
import 'FAST_Manual/fast_instructions.dart';
//import 'FAST_Manual/fast_reading_river_instructions.dart';
import 'phonemic_manual/main.dart';
import 'FAST_Automated/instructions.dart';
import 'results_generation/results_gen.dart';
import 'package:firebase_core/firebase_core.dart';

///Variables that cannot be imported
int _selectedTestIndex = 0;

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MaterialApp(home: const rollerSelection(), routes: {
    "phonemic fluency": (context) => const PhonemicFluencyInstructions(),
    "categoric fluency": (context) => const CategoricFluencyMain(),
    "verbal recognition (immediate)": (context) => const VerbalInstructions(),
    "verbal recognition (delayed)": (context) =>
        const DelayedMemoryTaskInstructions(),
    "moca": (context) => const mocaInstructions(),
    "fast": (context) => const FASTManualInstructions(),
    "phonemic fluency manual": (context) => const PhonemicManualStart(),
    "results": (context) => const resultsScreenFinal(),
    "fast final": (context) => const FASTinstructions()
  }));
}

///Roller for app selection

class rollerSelection extends StatefulWidget {
  const rollerSelection({super.key});
  @override
  State<rollerSelection> createState() => _rollerSelectionState();
}

class _rollerSelectionState extends State<rollerSelection> {
  ///initiating flutter speech to text in this component
  @override
  void initState() {
    super.initState();
    initSpeech();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text("Test Selection")),
        body: GestureDetector(
          child: Container(
              padding: const EdgeInsets.only(left: 300, bottom: 400),
              //alignment: Alignment.center,
              child: ListWheelScrollView(
                  itemExtent: 90,
                  magnification: 1.5,
                  useMagnifier: true,
                  offAxisFraction: 0.6,
                  physics: const FixedExtentScrollPhysics(),
                  diameterRatio: 1.2,
                  squeeze: 1,
                  onSelectedItemChanged: (index) => {
                        setState(() {
                          _selectedTestIndex = index;
                        })
                      },
                  children: testItems)),
          onTap: () => {
            ///MUST BE IMPLEMENTED AS A FUNCTION FOR CLEANER CODE

            Navigator.pushReplacementNamed(
                context, returnPageRoute(_selectedTestIndex))
          },
        ));
  }
}

//// End of roller for app selection
class temp extends StatefulWidget {
  const temp({super.key});

  @override
  State<temp> createState() => _tempState();
}

class _tempState extends State<temp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
