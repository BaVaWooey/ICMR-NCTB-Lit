import 'package:flutter/material.dart';
import 'styles.dart';

TextStyle getForHeader() {
  return ThemeText.forHeader;
}
