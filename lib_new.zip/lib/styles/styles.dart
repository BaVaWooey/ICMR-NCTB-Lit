////we define all the styles inside a class
///
import "package:flutter/material.dart";

abstract class ThemeText {
  static TextStyle forHeader = TextStyle(
    fontSize: 50,
  );
}
